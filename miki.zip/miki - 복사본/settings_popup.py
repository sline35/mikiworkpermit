import tkinter as tk
from tkinter import filedialog, messagebox
from ttkbootstrap.constants import *
from ttkbootstrap.widgets import Frame, Label, Entry, Button, Combobox
import os
import threading
import google.generativeai as genai
from config import GEMINI_API_KEY  # Import API key directly


class SettingsPopup(tk.Toplevel):
    def __init__(self, parent, main_app_instance):
        super().__init__(parent)
        self.main_app = main_app_instance
        self.title("⚙️ Settings")
        self.geometry("600x300") 
        self.resizable(False, False)

        # 모델 관련
        self.available_models = list(self.main_app.model_list) if self.main_app.model_list else []
        self.model_name_var = tk.StringVar(value=self.main_app.model_name)

        # API Key
        self.api_key_var = tk.StringVar(value=GEMINI_API_KEY if GEMINI_API_KEY and "paste_your_api_key_here" not in GEMINI_API_KEY else "")

        self.create_widgets()
        self._update_model_combobox(initial_load=True)

    def create_widgets(self):
        main_frame = Frame(self, padding=15)
        main_frame.pack(fill=tk.BOTH, expand=True)

        # --- 1. API Key 입력 ---
        api_frame = Frame(main_frame); api_frame.pack(fill=tk.X, pady=(0, 10)); api_frame.columnconfigure(1, weight=1)
        Label(api_frame, text="Gemini API Key", font=("Helvetica", 10)).grid(row=0, column=0, padx=(0, 5), sticky="w")

        self.api_entry = Entry(api_frame, textvariable=self.api_key_var, show="*", bootstyle=PRIMARY)
        self.api_entry.grid(row=0, column=1, sticky="ew", padx=(0, 5))

        clear_button = Button(api_frame, text="Clear", command=lambda: self.api_key_var.set(""), bootstyle="danger-outline", width=8)
        clear_button.grid(row=0, column=2, sticky="e")

        # --- 2. Data Save Path ---
        temp_path_frame = Frame(main_frame); temp_path_frame.pack(fill=tk.X, pady=(0, 10)); temp_path_frame.columnconfigure(1, weight=1)
        Label(temp_path_frame, text="Data Save Path", font=("Helvetica", 10)).grid(row=0, column=0, padx=(0, 5), sticky="w")
        self.temp_path_var = tk.StringVar(value=self.main_app.temp_dir)
        Entry(temp_path_frame, textvariable=self.temp_path_var, bootstyle=PRIMARY).grid(row=0, column=1, sticky="ew", padx=(0, 5))
        Button(temp_path_frame, text="Browse", command=lambda: self.select_directory(self.temp_path_var),
               bootstyle="secondary-outline", width=8).grid(row=0, column=2, sticky="e")

        # --- 3. PDF Save Path ---
        pdf_path_frame = Frame(main_frame); pdf_path_frame.pack(fill=tk.X, pady=(0, 10)); pdf_path_frame.columnconfigure(1, weight=1)
        Label(pdf_path_frame, text="PDF Save Path", font=("Helvetica", 10)).grid(row=0, column=0, padx=(0, 5), sticky="w")
        self.pdf_path_var = tk.StringVar(value=self.main_app.pdf_save_dir)
        Entry(pdf_path_frame, textvariable=self.pdf_path_var, bootstyle=PRIMARY).grid(row=0, column=1, sticky="ew", padx=(0, 5))
        Button(pdf_path_frame, text="Browse", command=lambda: self.select_directory(self.pdf_path_var),
               bootstyle="secondary-outline", width=8).grid(row=0, column=2, sticky="e")

        # --- 4. Model selection ---
        model_name_frame = Frame(main_frame)
        model_name_frame.pack(fill=tk.X, pady=(10, 10))
        model_name_frame.columnconfigure(1, weight=1)

        Label(model_name_frame, text="Gemini Model Name", font=("Helvetica", 10)).grid(row=0, column=0, padx=(0, 5), sticky="w")

        self.model_name_combobox = Combobox(model_name_frame,
                                            textvariable=self.model_name_var,
                                            values=self.available_models,
                                            bootstyle=INFO)
        self.model_name_combobox.grid(row=0, column=1, sticky="ew", padx=(0, 5))

        self.refresh_button = Button(model_name_frame, text="Refresh Models",
                                     command=self.start_model_discovery,
                                     bootstyle="warning-outline", width=12)
        self.refresh_button.grid(row=1, column=1, sticky="e", pady=(5, 0))  # 한 줄 아래 배치

        # --- 5. Save button ---
        save_button = Button(main_frame, text="Save Settings", command=self.save_settings, bootstyle="success")
        save_button.pack(pady=15)

    def select_directory(self, var):
        directory = filedialog.askdirectory()
        if directory:
            var.set(directory)

    def start_model_discovery(self):
        """Start model discovery in a separate thread"""
        api_key = self.api_key_var.get().strip()
        if not api_key:
            messagebox.showerror("Error", "You must provide a valid API key.")
            return

        self.refresh_button.config(text="Searching...", state='disabled')
        self.model_name_combobox.config(state='disabled', values=["Searching..."])
        self.model_name_combobox.set("Searching...")

        thread = threading.Thread(target=self._fetch_models_in_thread, args=(api_key,))
        thread.start()

    def _fetch_models_in_thread(self, api_key):
        """Fetch available models asynchronously"""
        try:
            genai.configure(api_key=api_key)
            models = genai.list_models()

            self.available_models = sorted([
                m.name.replace('models/', '')
                for m in models
                if 'generateContent' in m.supported_generation_methods
            ], reverse=True)

            self.main_app.master.after(0, self._update_model_combobox)

        except Exception as e:
            error_message = f"Error: Check API Key ({e})"
            self.available_models = [error_message]
            self.main_app.master.after(0, lambda: messagebox.showerror("API Error", f"Unable to fetch model list. ({e})"))
            self.main_app.master.after(0, self._update_model_combobox)

    def _update_model_combobox(self, initial_load=False):
        """Update combobox with discovered models"""
        if self.available_models and "Error" not in self.available_models[0]:
            self.model_name_combobox.config(values=self.available_models, state='normal')

            if not initial_load or self.model_name_var.get() not in self.available_models:
                default_model = next((m for m in self.available_models if 'flash' in m),
                                     self.model_name_var.get())
                self.model_name_combobox.set(default_model)
        else:
            self.model_name_combobox.config(values=[self.model_name_var.get()], state='normal')

        self.refresh_button.config(text="Refresh Models", state='normal')

    def save_settings(self):
        new_temp_path = self.temp_path_var.get()
        new_pdf_save_path = self.pdf_path_var.get()
        new_model_name = self.model_name_var.get().strip()
        new_api_key = self.api_key_var.get().strip()

        if not new_temp_path or not new_pdf_save_path or not new_model_name or not new_api_key:
            messagebox.showerror("Error", "You must specify all paths, API key, and a model name.")
            return

        config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.py")

        try:
            lines_to_write = []
            temp_dir_found = pdf_save_dir_found = model_name_found = model_list_found = api_key_found = False
            model_list_str = str(self.available_models)

            if os.path.exists(config_path):
                with open(config_path, "r", encoding="utf-8") as f:
                    lines = f.readlines()

                for line in lines:
                    line_stripped = line.strip()

                    if line_stripped.startswith("TEMP_DIR_PATH ="):
                        lines_to_write.append(f'TEMP_DIR_PATH = r"{new_temp_path}"\n')
                        temp_dir_found = True
                    elif line_stripped.startswith("PDF_SAVE_DIR_PATH ="):
                        lines_to_write.append(f'PDF_SAVE_DIR_PATH = r"{new_pdf_save_path}"\n')
                        pdf_save_dir_found = True
                    elif line_stripped.startswith("GEMINI_MODEL_NAME ="):
                        lines_to_write.append(f'GEMINI_MODEL_NAME = "{new_model_name}"\n')
                        model_name_found = True
                    elif line_stripped.startswith("GEMINI_MODEL_LIST ="):
                        lines_to_write.append(f'GEMINI_MODEL_LIST = {model_list_str}\n')
                        model_list_found = True
                    elif line_stripped.startswith("GEMINI_API_KEY ="):
                        lines_to_write.append(f'GEMINI_API_KEY = "{new_api_key}"\n')
                        api_key_found = True
                    else:
                        lines_to_write.append(line)

            if not temp_dir_found:
                lines_to_write.append(f'\nTEMP_DIR_PATH = r"{new_temp_path}"\n')
            if not pdf_save_dir_found:
                lines_to_write.append(f'\nPDF_SAVE_DIR_PATH = r"{new_pdf_save_path}"\n')
            if not model_name_found:
                lines_to_write.append(f'\nGEMINI_MODEL_NAME = "{new_model_name}"\n')
            if not model_list_found:
                lines_to_write.append(f'\nGEMINI_MODEL_LIST = {model_list_str}\n')
            if not api_key_found:
                lines_to_write.append(f'\nGEMINI_API_KEY = "{new_api_key}"\n')

            with open(config_path, "w", encoding="utf-8") as f:
                f.writelines(lines_to_write)

            # 업데이트
            self.main_app.update_settings(new_temp_path, new_pdf_save_path, new_model_name, self.available_models)
            messagebox.showinfo("Settings Saved", f"Settings saved successfully.\nModel: {new_model_name}")
            self.destroy()

        except Exception as e:
            messagebox.showerror("Error", f"Error while saving settings: {e}")
