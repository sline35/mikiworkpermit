import tkinter as tk
from tkinter import messagebox, scrolledtext, Listbox, Scrollbar
from tkinter.filedialog import askopenfilename
import json
import os
import threading
import datetime
from ttkbootstrap.constants import *
from ttkbootstrap.widgets import Frame, Label, Button, Combobox, Entry
from tkinter import Checkbutton
from ttkbootstrap import Style
import re

class AdvancedSearchPopup(tk.Toplevel):
    def __init__(self, parent, apply_callback, subcontractors_file_path):
        super().__init__(parent)
        self.title("🔍 Advanced Search")
        self.geometry("400x520")
        self.grab_set()
        self.resizable(False, False)

        self.apply_callback = apply_callback
        self.subcontractors_file = subcontractors_file_path

        main_frame = Frame(self, padding=15)
        main_frame.pack(fill=BOTH, expand=True)

        Label(main_frame, text="Company", font=("Helvetica", 10)).pack(fill=X, pady=(0, 5))
        company_frame = Frame(main_frame)
        company_frame.pack(fill=X, pady=(0, 10))

        self.bm_var = tk.BooleanVar(value=True)
        self.oh_var = tk.BooleanVar(value=True)
        self.oh2_var = tk.BooleanVar(value=True)

        Checkbutton(company_frame, text="SK BM", variable=self.bm_var).pack(side=LEFT, padx=(0, 10))
        Checkbutton(company_frame, text="SK OH", variable=self.oh_var).pack(side=LEFT, padx=(0, 10))
        Checkbutton(company_frame, text="SK OH2", variable=self.oh2_var).pack(side=LEFT)

        Label(main_frame, text="Date Range", font=("Helvetica", 10)).pack(fill=X, pady=(0, 5))
        
        start_date_frame = Frame(main_frame)
        start_date_frame.pack(fill=X, pady=(0, 5))
        Label(start_date_frame, text="Start:", width=6).pack(side=LEFT)
        self.start_year_cb = self.create_year_combobox(start_date_frame, "start")
        self.start_month_cb = self.create_month_combobox(start_date_frame, "start")
        self.start_day_cb = self.create_day_combobox(start_date_frame, "start")
        
        end_date_frame = Frame(main_frame)
        end_date_frame.pack(fill=X, pady=(0, 10))
        Label(end_date_frame, text="End:", width=6).pack(side=LEFT)
        self.end_year_cb = self.create_year_combobox(end_date_frame, "end")
        self.end_month_cb = self.create_month_combobox(end_date_frame, "end")
        self.end_day_cb = self.create_day_combobox(end_date_frame, "end")

        Label(main_frame, text="Building", font=("Helvetica", 10)).pack(fill=X, pady=(0, 5))
        self.building_entry = Entry(main_frame, bootstyle=INFO)
        self.building_entry.pack(fill=X, pady=(0, 10))
        
        Label(main_frame, text="Subcontractor", font=("Helvetica", 10)).pack(fill=X, pady=(0, 5))
        self.subcontractor_cb = Combobox(main_frame, bootstyle=INFO, width=37)
        self.subcontractor_cb.pack(fill=X, pady=(0, 10))
        self.load_subcontractors()

        Label(main_frame, text="Search Term (Filename/Keyword)", font=("Helvetica", 10)).pack(fill=X, pady=(0, 5))
        self.search_entry = Entry(main_frame, bootstyle=INFO)
        self.search_entry.pack(fill=X, pady=(0, 10))
        
        search_button = Button(main_frame, text="Search", command=self.apply_search, bootstyle=PRIMARY)
        search_button.pack(fill=X)
        
    def create_year_combobox(self, parent_frame, date_type):
        current_year = datetime.date.today().year
        years = [str(year) for year in range(current_year - 5, current_year + 6)]
        
        cb = Combobox(parent_frame, bootstyle=INFO, width=5, values=years)
        cb.pack(side=LEFT, padx=(5, 0))
        
        if date_type == "start":
            cb.set(str(current_year - 5))
        else:
            cb.set(str(current_year + 5))
            
        return cb

    def create_month_combobox(self, parent_frame, date_type):
        months = [f"{m:02d}" for m in range(1, 13)]
        
        cb = Combobox(parent_frame, bootstyle=INFO, width=4, values=months)
        cb.pack(side=LEFT, padx=(5, 0))
        
        if date_type == "start":
            cb.set("01")
        else:
            cb.set("12")
            
        return cb
        
    def create_day_combobox(self, parent_frame, date_type):
        days = [f"{d:02d}" for d in range(1, 32)]
        
        cb = Combobox(parent_frame, bootstyle=INFO, width=4, values=days)
        cb.pack(side=LEFT, padx=(5, 0))
        
        if date_type == "start":
            cb.set("01")
        else:
            cb.set("31")
            
        return cb
        
    def load_subcontractors(self):
        file_path = self.subcontractors_file 
        subcontractors = [""]
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                for line in f:
                    name_part = line.split(' - ')[0].strip()
                    if name_part:
                        subcontractors.append(name_part)
        except FileNotFoundError:
            print(f"Warning: The file {file_path} was not found. Subcontractor list empty.")
        except Exception as e:
            print(f"Error reading subcontractor file: {e}")
            
        unique_subcontractors = sorted(list(set(subcontractors)))
        self.subcontractor_cb['values'] = unique_subcontractors
        self.subcontractor_cb.set("")

    def apply_search(self):
        
        selected_companies = []
        if self.bm_var.get():
            selected_companies.append("sk_bm")
        if self.oh_var.get():
            selected_companies.append("sk_oh")
        if self.oh2_var.get():
            selected_companies.append("sk_oh2")
            
        start_date_str = f"{self.start_year_cb.get()}-{self.start_month_cb.get()}-{self.start_day_cb.get()}"
        end_date_str = f"{self.end_year_cb.get()}-{self.end_month_cb.get()}-{self.end_day_cb.get()}"
        
        building = self.building_entry.get().strip()
        selected_subcontractor = self.subcontractor_cb.get().strip()
        search_term = self.search_entry.get().strip()
        
        self.apply_callback(
            selected_companies, 
            start_date_str, 
            end_date_str, 
            building, 
            selected_subcontractor, 
            search_term
        )
        
        self.destroy()


class JSONViewerPopup(tk.Toplevel):
    def __init__(self, parent, master_app):
        super().__init__(parent)
        self.master_app = master_app
        self.title("📄 Load JSON File")
        self.geometry("800x600")
        self.grab_set()
        
        style = Style()
        style.configure('Tiny.TButton', font=("Helvetica", 6), padding=(0,0))

        self.temp_dir = self.master_app.temp_dir
        self.subcontractors_file = getattr(self.master_app, 'subcontractor_file', 'sub_contractors.TXT')

        self.file_paths = []
        self.current_loaded_file = None

        main_frame = Frame(self, padding=15)
        main_frame.pack(fill=BOTH, expand=True)

        top_frame = Frame(main_frame)
        top_frame.pack(fill=X, pady=(0, 10))
        
        Label(top_frame, text="Work Permit List", font=("Helvetica", 12, "bold")).pack(side=LEFT, padx=(0, 10))

        filter_frame = Frame(top_frame)
        filter_frame.pack(side=RIGHT, fill=X)
        
        self.search_button = Button(filter_frame, text="🔍 Advanced Search", command=self.open_advanced_search_popup, bootstyle=PRIMARY)
        self.search_button.pack(side=RIGHT)
        
        month_nav_frame = Frame(filter_frame)
        month_nav_frame.pack(side=RIGHT, padx=(0, 5))
        
        prev_month_btn = Button(month_nav_frame, text="▲", command=self._prev_month, bootstyle=PRIMARY, style='Tiny.TButton')
        prev_month_btn.pack(side=TOP, pady=(0, 1))

        next_month_btn = Button(month_nav_frame, text="▼", command=self._next_month, bootstyle=PRIMARY, style='Tiny.TButton')
        next_month_btn.pack(side=TOP)

        self.date_combobox = Combobox(filter_frame, bootstyle=PRIMARY, width=10)
        self.date_combobox.pack(side=RIGHT, padx=(5, 10))
        self.date_combobox.bind("<<ComboboxSelected>>", lambda event: self.filter_by_date())
        self.date_combobox.bind('<MouseWheel>', self._on_mousewheel)

        self.recent_button = Button(filter_frame, text="Recent", command=self.show_recent_files, bootstyle=PRIMARY)
        self.recent_button.pack(side=RIGHT, padx=(5, 5))

        file_list_frame = Frame(main_frame)
        file_list_frame.pack(fill=X, pady=(0, 10))
        
        self.file_listbox = Listbox(file_list_frame, height=10, font=("Helvetica", 10))
        self.file_listbox.pack(side=LEFT, fill=X, expand=True)
        
        file_scrollbar = Scrollbar(file_list_frame, orient=tk.VERTICAL, command=self.file_listbox.yview)
        file_scrollbar.pack(side=RIGHT, fill=Y)
        self.file_listbox.config(yscrollcommand=file_scrollbar.set)
        
        self.file_listbox.bind("<<ListboxSelect>>", self.on_file_select)
        self.file_listbox.bind("<Double-Button-1>", self.load_selected_file_with_event)

        viewer_frame = Frame(main_frame)
        viewer_frame.pack(fill=BOTH, expand=True, pady=(0, 10))
        
        Label(viewer_frame, text="File Preview", font=("Helvetica", 12, "bold")).pack(side=TOP, fill=X, pady=(0, 5))
        
        self.viewer_text = scrolledtext.ScrolledText(viewer_frame, wrap=tk.WORD, font=("Consolas", 10), state=tk.DISABLED, undo=True, height=7)
        self.viewer_text.pack(fill=BOTH, expand=True)

        bottom_button_frame = Frame(main_frame)
        bottom_button_frame.pack(fill=X)
        
        self.delete_button = Button(bottom_button_frame, text="Delete Selected File", command=self._delete_selected_file, bootstyle=DANGER)
        self.delete_button.pack(side=LEFT, expand=True, padx=(0, 5))
        
        self.load_button = Button(bottom_button_frame, text="Load Selected File", command=self.load_selected_file, bootstyle=PRIMARY)
        self.load_button.pack(side=LEFT, expand=True, padx=(0, 5))
        
        self.close_button = Button(bottom_button_frame, text="Close", command=self.destroy, bootstyle=DANGER)
        self.close_button.pack(side=RIGHT, expand=True, padx=(5, 0))
        
        self.populate_date_combobox()
        self.show_recent_files()

    def normalize_name(self, name):
        if not name:
            return ""
        
        cleaned_name = str(name).strip().lower()
        
        chars_to_remove = [' ', '_', '.', ',', '+', '(', ')', '[', ']', '{', '}', '\n', '\r']
        
        for char in chars_to_remove:
            cleaned_name = cleaned_name.replace(char, '')
            
        return cleaned_name
    
    def _prev_month(self):
        try:
            current_date_str = self.date_combobox.get()
            if not current_date_str: return
            current_date = datetime.datetime.strptime(current_date_str, "%Y-%m").date()
            
            first_day_of_month = current_date.replace(day=1)
            last_day_of_prev_month = first_day_of_month - datetime.timedelta(days=1)
            
            new_date_str = last_day_of_prev_month.strftime("%Y-%m")
            self.date_combobox.set(new_date_str)
            self.filter_by_date()
        except (ValueError, tk.TclError):
            pass

    def _next_month(self):
        try:
            current_date_str = self.date_combobox.get()
            if not current_date_str: return
            current_date = datetime.datetime.strptime(current_date_str, "%Y-%m").date()

            first_day_of_next_month = current_date.replace(day=28) + datetime.timedelta(days=4)
            while first_day_of_next_month.month == current_date.month:
                first_day_of_next_month += datetime.timedelta(days=1)
                
            new_date_str = first_day_of_next_month.strftime("%Y-%m")
            self.date_combobox.set(new_date_str)
            self.filter_by_date()
        except (ValueError, tk.TclError):
            pass

    def open_advanced_search_popup(self):
        import json_viewer_popup
        self.subcontractors_file = getattr(self.master_app, 'subcontractor_file', 'sub_contractors.TXT')
        json_viewer_popup.AdvancedSearchPopup(self, self.filter_by_advanced_search, self.subcontractors_file)

    def filter_by_advanced_search(self, selected_companies, start_date_str, end_date_str, building, selected_subcontractor, search_term):

        search_term_for_comparison = search_term.lower().strip()

        building_for_comparison = building.lower().strip()

        raw_company_part = selected_subcontractor.split('-')[0].strip()
        
        cleaned_selected_subcontractor = self.normalize_name(raw_company_part)
        
        self.file_listbox.delete(0, tk.END)
        self.file_paths.clear()

        if not os.path.exists(self.temp_dir):
            messagebox.showerror("Error", f"Search directory not found: {self.temp_dir}", parent=self)
            return
            
        json_files = [f for f in os.listdir(self.temp_dir) if f.endswith('.json')]
        files_to_display = []

        start_date_obj = None
        end_date_obj = None
        date_format = "%Y-%m-%d"

        try:
            if start_date_str and start_date_str.count('-') == 2:
                start_date_obj = datetime.datetime.strptime(start_date_str, date_format).date()
        except ValueError:
            pass

        try:
            if end_date_str and end_date_str.count('-') == 2:
                end_date_obj = datetime.datetime.strptime(end_date_str, date_format).date()
        except ValueError:
            pass


        for file in json_files:
            lower_file = file.lower()
            file_path = os.path.join(self.temp_dir, file)
            
            file_segments = file.split('-')
            
            match_company = any(c in lower_file for c in selected_companies) if selected_companies else True
            if not match_company: continue

            match_building = True
            if building_for_comparison:
                try:
                    if len(file_segments) > 4:
                        file_building_segment = file_segments[4].strip().lower()
                        if building_for_comparison not in file_building_segment:
                            match_building = False
                    else:
                        match_building = False
                except Exception:
                    match_building = False
            if not match_building: continue

            match_subcontractor = True
            if cleaned_selected_subcontractor:
                try:
                    if len(file_segments) > 5:
                        file_subcontractor_segment = file_segments[5].strip()
                        cleaned_file_subcontractor = self.normalize_name(file_subcontractor_segment)
                        
                        if cleaned_file_subcontractor not in cleaned_selected_subcontractor: 
                            match_subcontractor = False
                    else:
                        match_subcontractor = False
                except Exception:
                    match_subcontractor = False
            if not match_subcontractor: continue            
            
            match_date = True
            if start_date_obj or end_date_obj:
                try:
                    file_date_str = file_segments[0] + "-" + file_segments[1] + "-" + file_segments[2]
                    full_file_date_str = file_date_str if len(file_date_str) == 10 else f"20{file_date_str}"
                    file_date_obj = datetime.datetime.strptime(full_file_date_str, date_format).date()
                    
                    if start_date_obj and file_date_obj < start_date_obj:
                        match_date = False
                    if end_date_obj and file_date_obj > end_date_obj:
                        match_date = False
                except (ValueError, IndexError):
                    match_date = False
            if not match_date: continue

            match_search_term_content = True
            
            if search_term_for_comparison:
                search_term_for_filename = search_term_for_comparison.replace(' ', '_')
                
                match_search_term_content = search_term_for_filename in lower_file
                
            needs_content_read = search_term_for_comparison and not match_search_term_content

            if needs_content_read:
                try:
                    with open(file_path, "r", encoding="utf-8") as f:
                        data = json.load(f)
                    
                    user_inputs = data.get("user_inputs", {})
                    gemini_response = data.get("gemini_response", {})
                    
                    search_term_for_content = search_term_for_comparison.replace('_', ' ')
                    
                    work_details_en = gemini_response.get("WORK DETAILS EN", "").strip().lower()
                    task_desc = user_inputs.get("task_description", "").strip().lower()
                    
                    if search_term_for_content in work_details_en or \
                       search_term_for_content in task_desc or \
                       search_term_for_filename in work_details_en or \
                       search_term_for_filename in task_desc:
                        
                        match_search_term_content = True
                    else:
                        match_search_term_content = False
                        
                except (json.JSONDecodeError, FileNotFoundError, KeyError, AttributeError):
                    match_search_term_content = False
                    
            if match_search_term_content:
                files_to_display.append({'path': file_path, 'name': file, 'time': os.path.getmtime(file_path)})

        sorted_files = sorted(files_to_display, key=lambda x: x['time'], reverse=True)
        self.populate_file_list(sorted_files)
        
        is_search_active = building or selected_subcontractor or search_term or not selected_companies or start_date_obj or end_date_obj
        if not sorted_files and is_search_active:
            messagebox.showinfo("Search Result", "No files matched the search criteria.", parent=self)

    def populate_date_combobox(self):
        dates = []
        today = datetime.date.today()
        for year in range(today.year - 5, today.year + 6):
            for month in range(1, 13):
                dates.append(f"{year}-{month:02d}")
        
        self.date_combobox['values'] = dates
        self.date_combobox.set(today.strftime('%Y-%m'))
        
    def _on_mousewheel(self, event):
        current_value = self.date_combobox.get()
        values = list(self.date_combobox['values'])
        try:
            current_index = values.index(current_value)
        except ValueError:
            return

        if event.delta > 0:
            if current_index > 0:
                self.date_combobox.set(values[current_index - 1])
        else:
            if current_index < len(values) - 1:
                self.date_combobox.set(values[current_index + 1])
        
        self.filter_by_date()

    def populate_file_list(self, files_to_display):
        self.file_listbox.delete(0, tk.END)
        self.file_paths.clear()

        for file_info in files_to_display:
            file_path = file_info['path']
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    user_inputs = data.get("user_inputs", {})
                    
                    start_date_str = user_inputs.get("start_date", "NoDate")
                    start_date = start_date_str.replace("-", "")
                    company = user_inputs.get("company", "NoCompany")
                    building = user_inputs.get("building", "NoBuilding")
                    task_description = user_inputs.get("task_description", "NoDescription").strip()
                    
                    task_name = task_description.split("\n")[0] if "\n" in task_description else task_description
                    
                    display_text = f"[{start_date}] {company} {building} - {task_name}"
                    
                    self.file_listbox.insert(tk.END, display_text)
                    self.file_paths.append(file_path)
                    
            except (json.JSONDecodeError, FileNotFoundError, KeyError) as e:
                print(f"Skipping corrupted or invalid file: {file_info['name']} - {e}")
                self.file_listbox.insert(tk.END, f"[Error] {file_info['name']}")
                self.file_paths.append(file_path)

    def show_recent_files(self):
        if not os.path.exists(self.temp_dir):
            self.populate_file_list([])
            return

        json_files = [f for f in os.listdir(self.temp_dir) if f.endswith('.json')]
        
        file_list_with_times = []
        for file in json_files:
            file_path = os.path.join(self.temp_dir, file)
            try:
                mod_time = os.path.getmtime(file_path)
                file_list_with_times.append({'path': file_path, 'name': file, 'time': mod_time})
            except Exception:
                continue
        
        sorted_files = sorted(file_list_with_times, key=lambda x: x['time'], reverse=True)
        recent_10_files = sorted_files[:10]
        
        self.populate_file_list(recent_10_files)

    def filter_by_date(self):
        selected_date = self.date_combobox.get()
        
        if not selected_date or selected_date == datetime.date.today().strftime('%Y-%m'):
            self.show_recent_files()
            return
            
        try:
            year, month = map(int, selected_date.split('-'))
            
            if not os.path.exists(self.temp_dir):
                self.populate_file_list([])
                return
            
            filtered_files = []
            for file in os.listdir(self.temp_dir):
                file_path = os.path.join(self.temp_dir, file)
                if file.endswith('.json'):
                    try:
                        with open(file_path, "r", encoding="utf-8") as f:
                            data = json.load(f)
                            start_date_str = data.get("user_inputs", {}).get("start_date", "")
                            
                            if start_date_str and start_date_str[:7] == f"{year}-{month:02d}":
                                filtered_files.append({'path': file_path, 'name': file})
                    except (json.JSONDecodeError, FileNotFoundError, KeyError):
                        continue
            
            sorted_files = sorted(filtered_files, key=lambda x: x['name'], reverse=True)
            self.populate_file_list(sorted_files)
        
        except ValueError:
            messagebox.showwarning("Warning", "Please select a valid date format.")

    def on_file_select(self, event):
        selected_index = self.file_listbox.curselection()
        if not selected_index:
            return

        selected_file_path = self.file_paths[selected_index[0]]
        self.current_loaded_file = selected_file_path
        
        self.viewer_text.config(state=tk.NORMAL)
        self.viewer_text.delete("1.0", tk.END)
        
        try:
            with open(selected_file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                
                user_inputs = data.get("user_inputs", {})
                gemini_response = data.get("gemini_response", {})
                
                start_date = user_inputs.get("start_date", "N/A")
                end_date = user_inputs.get("end_date", "N/A")
                company = user_inputs.get("company", "N/A")
                building = user_inputs.get("building", "N/A")
                subcontractor_full = user_inputs.get("subcontractor_full", "N/A")
                # <<< 수정: 담당자 정보 추가
                responsible_person_manager_full = user_inputs.get("responsible_person_manager_full", "N/A")
                # >>>
                task_description = user_inputs.get("task_description", "N/A")

                work_details_en = gemini_response.get("WORK DETAILS EN", "N/A")
                permits_data = user_inputs.get("permits", {})
                checked_permits = []
                permit_names = {
                    "fire": "Hot Work",
                    "enclosed": "Confined Space",
                    "heavy_machinery": "Heavy Machinery",
                    "electrical": "Electrical Work",
                    "high_place": "Work at Height",
                    "hazardous_material": "Hazardous Material"
                }
                for key, value in permits_data.items():
                    if value:
                        checked_permits.append(permit_names.get(key, key))
                
                permits_text = ", ".join(checked_permits) if checked_permits else "None"
                
                display_text = (
                    f"========== File Information ==========\n"
                    f"Date: {start_date} ~ {end_date}\n"
                    f"Company: {company}\n"
                    f"Building: {building}\n"
                    f"Subcontractor: {subcontractor_full}\n"
                    # <<< 수정: 담당자 정보 출력 추가
                    f"Responsible Manager: {responsible_person_manager_full}\n"
                    # >>>
                    f"Hazardous Work: {permits_text}\n"
                    f"-------------------------------\n"
                    f"Task Description:\n"
                    f"{task_description}\n\n"
                    f"========== Gemini API Information ==========\n"
                    f"WORK DETAILS EN:\n"
                    f"{work_details_en}"
                )
                
                self.viewer_text.insert("1.0", display_text)

        except Exception as e:
            self.viewer_text.insert("1.0", f"An error occurred while reading the file: {e}")
        
        self.viewer_text.config(state=tk.DISABLED)
        

    def load_selected_file_with_event(self, event):
        self.load_selected_file()

    def load_selected_file(self):
        selected_index = self.file_listbox.curselection()
        if not selected_index:
            messagebox.showwarning("Warning", "Please select a file.")
            return

        selected_file_path = self.file_paths[selected_index[0]]
        file_name = os.path.basename(selected_file_path)

        thread = threading.Thread(target=self._run_load_in_thread, args=(selected_file_path, file_name))
        thread.start()
        
    def _run_load_in_thread(self, file_path, file_name):
        try:
            with open(file_path, "r", encoding="utf-8") as json_file:
                combined_data = json.load(json_file)
            
            user_inputs = combined_data.get("user_inputs", {})
            jsa_json = combined_data.get("gemini_response", {})
            
            permits_data = user_inputs.get("permits", {})
            self.master_app.master.after(0, lambda: self.master_app.fire_permit_var.set(permits_data.get("fire", False)))
            self.master_app.master.after(0, lambda: self.master_app.enclosed_permit_var.set(permits_data.get("enclosed", False)))
            self.master_app.master.after(0, lambda: self.master_app.heavy_machinery_permit_var.set(permits_data.get("heavy_machinery", False)))
            self.master_app.master.after(0, lambda: self.master_app.electrical_permit_var.set(permits_data.get("electrical", False)))
            self.master_app.master.after(0, lambda: self.master_app.high_place_permit_var.set(permits_data.get("high_place", False)))
            self.master_app.master.after(0, lambda: self.master_app.hazardous_material_permit_var.set(permits_data.get("hazardous_material", False)))

            try:
                with open(self.master_app.generated_json_path, "w", encoding="utf-8") as f:
                    json.dump(combined_data, f, ensure_ascii=False, indent=4)
                print("preview_temp_output.json updated successfully.")
            except Exception as e:
                print(f"Error updating preview_temp_output.json: {e}")
            
            def set_date_fields(prefix, date_str):
                if date_str and len(date_str) >= 10:
                    try:
                        year, month, day = date_str.split('-')
                        getattr(self.master_app, f"{prefix}_year_entry").delete(0, tk.END)
                        getattr(self.master_app, f"{prefix}_year_entry").insert(0, year)
                        getattr(self.master_app, f"{prefix}_month_entry").delete(0, tk.END)
                        getattr(self.master_app, f"{prefix}_month_entry").insert(0, month)
                        getattr(self.master_app, f"{prefix}_day_entry").delete(0, tk.END)
                        getattr(self.master_app, f"{prefix}_day_entry").insert(0, day)
                    except (ValueError, AttributeError):
                        pass
                        
            self.master_app.master.after(0, lambda: set_date_fields("creation", user_inputs.get("creation_date", "")))
            self.master_app.master.after(0, lambda: set_date_fields("start", user_inputs.get("start_date", "")))
            self.master_app.master.after(0, lambda: set_date_fields("end", user_inputs.get("end_date", "")))
            
            self.master_app.master.after(0, lambda: self.master_app.company_var.set(user_inputs.get("company", "")))
            
            self.master_app.master.after(0, lambda: self.master_app.building_entry.delete(0, tk.END))
            self.master_app.master.after(0, lambda: self.master_app.building_entry.insert(0, user_inputs.get("building", "")))
            
            self.master_app.master.after(0, lambda: self.master_app.floor_entry.delete(0, tk.END))
            self.master_app.master.after(0, lambda: self.master_app.floor_entry.insert(0, user_inputs.get("floor", "")))
            
            self.master_app.master.after(0, lambda: self.master_app.subcontractor_combobox.set(user_inputs.get("subcontractor_full", "")))
            
            self.master_app.master.after(0, lambda: self.master_app.responsible_person_manager_combobox.set(user_inputs.get("responsible_person_manager_full", "")))
            
            self.master_app.master.after(0, lambda: self.master_app.fire_alarm_var.set(user_inputs.get("fire_alarm_status", "None")))
            
            self.master_app.master.after(0, lambda: self.master_app.task_description_entry.delete("1.0", tk.END))
            self.master_app.master.after(0, lambda: self.master_app.task_description_entry.insert("1.0", user_inputs.get("task_description", "")))
            
            self.master_app.jsa_json = jsa_json

            self.master_app.master.after(0, lambda: messagebox.showinfo(
                "Load Complete", 
                f"Information from '{file_name}' has been successfully loaded.", 
                parent=self.master_app.master
            ))
            self.master_app.master.after(0, self.destroy)

        except Exception as e:
            self.master_app.master.after(0, lambda: messagebox.showerror(
                "Load Error", 
                f"An error occurred while reading the file: {e}",
                parent=self.master_app.master
            ))
            self.master_app.master.after(0, self.destroy)
            
    def _delete_selected_file(self):
        selected_index = self.file_listbox.curselection()
        if not selected_index:
            messagebox.showwarning("Warning", "Please select a file to delete.", parent=self)
            return

        try:
            file_path = self.file_paths[selected_index[0]]
            file_name = os.path.basename(file_path)
        except IndexError:
            messagebox.showerror("Error", "Could not find information for the selected file.", parent=self)
            return

        response = messagebox.askyesno("Confirm", f"Are you sure you want to delete '{file_name}'?\nThis action cannot be undone.", parent=self)
        if response:
            try:
                os.remove(file_path)
                messagebox.showinfo("Deleted", f"'{file_name}' has been deleted successfully.", parent=self)
                self.show_recent_files()
                self.viewer_text.config(state=tk.NORMAL)
                self.viewer_text.delete("1.0", tk.END)
                self.viewer_text.config(state=tk.DISABLED)
            except Exception as e:
                messagebox.showerror("Delete Error", f"An error occurred while deleting the file: {e}", parent=self)

    def browse_file(self):
        file_path = askopenfilename(
            defaultextension=".json",
            filetypes=[("JSON files", "*.json")],
            initialdir=self.temp_dir
        )
        if not file_path:
            return

        file_name = os.path.basename(file_path)
        
        thread = threading.Thread(target=self._run_load_in_thread, args=(file_path, file_name))
        thread.start()
