import google.generativeai as genai
import sys

def get_configured_model(api_key, model_type="flash"):
    """
    API 키로 Gemini를 설정하고, 지정된 타입의 최신 모델을 찾아 반환합니다.

    Args:
        api_key (str): Gemini API 키.
        model_type (str): 찾고 싶은 모델의 종류 ('flash', 'pro' 등).

    Returns:
        genai.GenerativeModel: 설정이 완료된 모델 객체.
    """
    try:
        genai.configure(api_key=api_key)
        
        available_models = [
            m.name for m in genai.list_models()
            if 'generateContent' in m.supported_generation_methods
        ]
        
        model_name = None
        
        if model_type == 'flash':
            if 'models/gemini-2.5-flash' in available_models:
                model_name = 'gemini-2.5-flash'
            elif 'models/gemini-flash-latest' in available_models:
                model_name = 'gemini-flash-latest'
            elif 'models/gemini-1.5-flash' in available_models:
                model_name = 'gemini-1.5-flash'
            else:
                for name in sorted(available_models, reverse=True):
                    if 'gemini-2.5-flash-preview' in name:
                        model_name = name
                        break

        elif model_type == 'pro':
            if 'models/gemini-2.5-pro' in available_models:
                model_name = 'gemini-2.5-pro'
            elif 'models/gemini-pro-latest' in available_models:
                model_name = 'gemini-pro-latest'
            elif 'models/gemini-1.5-pro' in available_models:
                model_name = 'gemini-1.5-pro'
            else:
                for name in sorted(available_models, reverse=True):
                    if 'gemini-2.5-pro-preview' in name:
                        model_name = name
                        break
                        
        if model_name:
            return genai.GenerativeModel(model_name=model_name)
        else:
            return None
    
    except Exception as e:
        print(f"API 모델 설정 중 오류 발생: {e}", file=sys.stderr)
        return None
