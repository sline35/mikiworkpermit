import tkinter as tk
from tkinter import messagebox
from ttkbootstrap.constants import *
from ttkbootstrap.widgets import Frame, Label, Entry, Button
import os


# -----------------------------
# Modify Popup: Name / Phone (Company field removed)
# -----------------------------
class ModifyPersonPopup(tk.Toplevel):
    def __init__(self, parent, responsible_persons_file, update_callback, person_data, index):
        super().__init__(parent)
        self.title("Edit Manager Info (Name/Phone)") # 타이틀 수정
        self.geometry("360x150") # 높이 축소
        self.grab_set()

        self.responsible_persons_file = responsible_persons_file
        self.update_callback = update_callback
        # Company 필드 제거
        self.person_data = {
            'company': '', # 관리자에 대해서는 항상 빈 문자열로 유지
            'name': person_data.get('name', ''),
            'phone': person_data.get('phone', '')
        }
        self.index = index

        main_frame = Frame(self, padding=15)
        main_frame.pack(fill=tk.BOTH, expand=True)

        # Name (Row 0으로 변경)
        Label(main_frame, text="Name:", font=("Helvetica", 10)).grid(
            row=0, column=0, sticky="w", padx=(0, 5), pady=(0, 5)
        )
        self.name_entry = Entry(main_frame, bootstyle=PRIMARY, font=("Helvetica", 10))
        self.name_entry.grid(row=0, column=1, sticky="ew", pady=(0, 5))
        self.name_entry.insert(0, self.person_data['name'])

        # Phone (Row 1로 변경)
        Label(main_frame, text="Phone:", font=("Helvetica", 10)).grid(
            row=1, column=0, sticky="w", padx=(0, 5), pady=(0, 10)
        )
        self.phone_entry = Entry(main_frame, bootstyle=PRIMARY, font=("Helvetica", 10))
        self.phone_entry.grid(row=1, column=1, sticky="ew", pady=(0, 10))
        self.phone_entry.insert(0, self.person_data['phone'])

        self.name_entry.focus_set()

        button_frame = Frame(main_frame)
        button_frame.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(10, 0)) # Row 2로 변경

        save_button = Button(button_frame, text="Save", command=self.save_changes, bootstyle=SUCCESS)
        save_button.pack(side=tk.RIGHT)

        cancel_button = Button(button_frame, text="Cancel", command=self.destroy, bootstyle=DANGER)
        cancel_button.pack(side=tk.RIGHT, padx=(0, 5))

        self.bind("<Return>", lambda e: self.save_changes())

    def save_changes(self):
        new_name = self.name_entry.get().strip()
        new_phone = self.phone_entry.get().strip()

        if not new_name:
            messagebox.showwarning("Input Error", "Please enter a name.", parent=self)
            return

        self.person_data['company'] = '' # 강제로 빈 문자열로 저장
        self.person_data['name'] = new_name
        self.person_data['phone'] = new_phone

        self.update_callback(self.index, self.person_data)

        messagebox.showinfo("Update Successful", "Manager info updated successfully.", parent=self)
        self.destroy()


# -----------------------------------------
# Responsible Person Manager: Name / Phone (Company field removed)
# -----------------------------------------
class ResponsiblePersonManager(tk.Toplevel):
    """
    - File format: company,name,phone (CSV, company is empty for manager)
    - Display format: 'Name (Phone)'
    - update_combobox_callback: callback to refresh combobox values
    """
    def __init__(self, parent_app, responsible_persons_file, update_combobox_callback):
        super().__init__(parent_app.master)
        self.title("Responsible Person Manager (Managers)")
        self.geometry("450x420")

        # 🟢 전달받은 절대 경로 (responsible_persons_file)를 사용
        self.responsible_persons_file = responsible_persons_file
        
        self.update_combobox_callback = update_combobox_callback
        self.parent_app = parent_app

        main_frame = Frame(self, padding=10)
        main_frame.pack(fill=tk.BOTH, expand=True)

        # List area
        list_frame = Frame(main_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))

        scrollbar = tk.Scrollbar(list_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.person_listbox = tk.Listbox(
            list_frame, height=15, font=("Helvetica", 10),
            yscrollcommand=scrollbar.set, selectmode=tk.SINGLE
        )
        self.person_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.person_listbox.yview)

        self.person_listbox.bind("<Double-1>", self._on_double_click)

        # Load data
        self.load_list()

        # Input area
        entry_frame = Frame(main_frame)
        entry_frame.pack(fill=tk.X, pady=(0, 5))
        entry_frame.columnconfigure(1, weight=1)
        entry_frame.columnconfigure(3, weight=1)
        
        # Name 필드
        Label(entry_frame, text="Name:", font=("Helvetica", 10)).grid(row=0, column=0, sticky="w", padx=(0, 5))
        self.new_person_entry = Entry(entry_frame, bootstyle=PRIMARY, font=("Helvetica", 10))
        self.new_person_entry.grid(row=0, column=1, sticky="ew")

        # Phone 필드
        Label(entry_frame, text="Phone:", font=("Helvetica", 10)).grid(row=0, column=2, sticky="w", padx=(10, 5))
        self.new_phone_entry = Entry(entry_frame, bootstyle=PRIMARY, font=("Helvetica", 10))
        self.new_phone_entry.grid(row=0, column=3, sticky="ew")
        
        # Button area
        button_frame = Frame(main_frame)
        button_frame.pack(fill=tk.X)

        add_button = Button(button_frame, text="Add", command=self.add_person, bootstyle=SUCCESS, width=8)
        add_button.pack(side=tk.LEFT, padx=(0, 5))

        modify_button = Button(button_frame, text="Edit", command=self.modify_person, bootstyle=WARNING, width=8)
        modify_button.pack(side=tk.LEFT, padx=5)

        delete_button = Button(button_frame, text="Delete", command=self.delete_person, bootstyle=DANGER, width=8)
        delete_button.pack(side=tk.LEFT, padx=(5, 0))

        self.bind("<Return>", lambda e: self.add_person())

    # -------- Utility --------
    def _display_text(self, person: dict) -> str:
        """List/combobox display format: 'Name (Phone)'"""
        name = person.get('name', '').strip()
        phone = person.get('phone', '').strip()

        if phone:
            return f"{name} ({phone})"
        return name

    # -------- File I/O --------
    def load_list(self):
        """Load person list from file (Reads 'company,name,phone' format, 2필드도 처리 가능)"""
        self.person_listbox.delete(0, tk.END)
        self.persons = []

        if os.path.exists(self.responsible_persons_file):
            with open(self.responsible_persons_file, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue

                    parts = line.split(',')
                    
                    if len(parts) >= 3:
                        # 3개 필드 이상 (기존 형식 유지)
                        company = parts[0].strip()
                        name = parts[1].strip()
                        phone = ','.join(parts[2:]).strip()
                    elif len(parts) == 2:
                        # 2개 필드 (관리자 명단)
                        company = ""
                        name = parts[0].strip()
                        phone = parts[1].strip()
                    else:
                        continue 

                    person = {'company': company, 'name': name, 'phone': phone}
                    self.persons.append(person)
                    self.person_listbox.insert(tk.END, self._display_text(person))

    def save_list(self):
        """Save list changes to file (Writes 'company,name,phone' format)"""
        try:
            with open(self.responsible_persons_file, "w", encoding="utf-8") as f:
                for person in self.persons:
                    # 회사는 항상 빈 문자열로 저장하여 포맷 유지
                    company = person.get('company', '').replace('\n', ' ').strip()
                    name = person.get('name', '').replace('\n', ' ').strip()
                    phone = person.get('phone', '').replace('\n', ' ').strip()
                    f.write(f"{company},{name},{phone}\n")
        except Exception as e:
            messagebox.showerror("File Save Error", f"An error occurred while saving: {e}", parent=self)

    # -------- CRUD Handlers --------
    def add_person(self):
        """Add a new person"""
        new_company = '' 
        new_name = self.new_person_entry.get().strip()
        new_phone = self.new_phone_entry.get().strip()

        if not new_name:
            messagebox.showwarning("Input Error", "Please enter a name.", parent=self)
            return

        for p in self.persons:
            if (
                p.get('company', '') == new_company
                and p.get('name', '') == new_name
                and p.get('phone', '') == new_phone
            ):
                messagebox.showwarning("Duplicate", "This person already exists.", parent=self)
                return

        new_person = {'company': new_company, 'name': new_name, 'phone': new_phone}
        self.persons.append(new_person)
        self.person_listbox.insert(tk.END, self._display_text(new_person))

        # Clear entries
        self.new_person_entry.delete(0, tk.END)
        self.new_phone_entry.delete(0, tk.END)

        self.save_list()
        messagebox.showinfo("Added Successfully", f"'{self._display_text(new_person)}' has been added.", parent=self)

        if callable(self.update_combobox_callback):
            self.update_combobox_callback([self._display_text(p) for p in self.persons])
                 
    def modify_person(self):
        """Open popup to edit selected Responsible Person"""
        selected_indices = self.person_listbox.curselection()
        if not selected_indices:
            messagebox.showwarning("Selection Error", "Please select a Responsible Person to edit.", parent=self)
            return

        selected_index = selected_indices[0]
        person_data_to_modify = self.persons[selected_index]

        ModifyPersonPopup(
            self, self.responsible_persons_file, self.update_person_in_list,
            person_data_to_modify, selected_index
        )

    def update_person_in_list(self, index, updated_data):
        """Apply updated data from popup"""
        updated = {
            'company': '', 
            'name': updated_data.get('name', '').strip(),
            'phone': updated_data.get('phone', '').strip()
        }
        self.persons[index] = updated
        self.save_list()
        self.load_list()
        self.update_combobox_callback([self._display_text(p) for p in self.persons])

    def delete_person(self):
        """Delete selected Responsible Person"""
        selected_indices = self.person_listbox.curselection()
        if not selected_indices:
            messagebox.showwarning("Selection Error", "Please select a Responsible Person to delete.", parent=self)
            return

        if not messagebox.askyesno("Delete Confirmation", "Are you sure you want to delete this Responsible Person?", parent=self):
            return

        for index in reversed(selected_indices):
            del self.persons[index]

        self.save_list()
        self.load_list()
        self.update_combobox_callback([self._display_text(p) for p in self.persons])

        messagebox.showinfo("Delete Successful", "Selected person has been deleted.", parent=self)

    # -------- UX: Double Click --------
    def _on_double_click(self, event):
        """On double click, set selection in combobox and close"""
        try:
            selected_index = self.person_listbox.curselection()[0]
            person_data = self.persons[selected_index]
            display_text = self._display_text(person_data)
            self.parent_app.responsible_person_manager_combobox.set(display_text) 
            self.destroy()
        except IndexError:
            pass
