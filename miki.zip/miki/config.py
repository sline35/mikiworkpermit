# config.py
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Gemini API 키
GEMINI_API_KEY = "AIzaSyC8WRBAm9SQwSzyeG8SXQfuhVvfcY__0g8"

# 사용할 Gemini 모델 이름을 여기에 지정합니다. (설정 팝업에서 수정됨)
GEMINI_MODEL_NAME = "gemini-flash-lite-latest"

# ✨ 이전에 검색된 모델 목록이 여기에 저장됩니다. ✨
GEMINI_MODEL_LIST = ['learnlm-2.0-flash-experimental', 'gemma-3n-e4b-it', 'gemma-3n-e2b-it', 'gemma-3-4b-it', 'gemma-3-27b-it', 'gemma-3-1b-it', 'gemma-3-12b-it', 'gemini-robotics-er-1.5-preview', 'gemini-pro-latest', 'gemini-flash-lite-latest', 'gemini-flash-latest', 'gemini-exp-1206', 'gemini-2.5-pro-preview-tts', 'gemini-2.5-pro-preview-06-05', 'gemini-2.5-pro-preview-05-06', 'gemini-2.5-pro-preview-03-25', 'gemini-2.5-pro', 'gemini-2.5-flash-preview-tts', 'gemini-2.5-flash-preview-09-2025', 'gemini-2.5-flash-preview-05-20', 'gemini-2.5-flash-lite-preview-09-2025', 'gemini-2.5-flash-lite-preview-06-17', 'gemini-2.5-flash-lite', 'gemini-2.5-flash-image-preview', 'gemini-2.5-flash-image', 'gemini-2.5-flash', 'gemini-2.5-computer-use-preview-10-2025', 'gemini-2.0-pro-exp-02-05', 'gemini-2.0-pro-exp', 'gemini-2.0-flash-thinking-exp-1219', 'gemini-2.0-flash-thinking-exp-01-21', 'gemini-2.0-flash-thinking-exp', 'gemini-2.0-flash-lite-preview-02-05', 'gemini-2.0-flash-lite-preview', 'gemini-2.0-flash-lite-001', 'gemini-2.0-flash-lite', 'gemini-2.0-flash-exp', 'gemini-2.0-flash-001', 'gemini-2.0-flash']

# 데이터 파일 경로 설정
TEMP_DIR_PATH = r"C:/Users/sline/OneDrive/바탕 화면/work permit maker for miki/temp"
#TEMP_DIR_PATH = os.path.join(BASE_DIR, "temp")

# 새로운 PDF 저장 경로 설정
PDF_SAVE_DIR_PATH = r"C:/Users/sline/OneDrive/바탕 화면/work permit maker for miki/workpermit"
#PDF_SAVE_DIR_PATH = os.path.join(BASE_DIR, "workpermit")
